/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/extensions/devtools/devtools.ts":
/*!*********************************************!*\
  !*** ./src/extensions/devtools/devtools.ts ***!
  \*********************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
const devtools_service_1 = __webpack_require__(/*! @services/devtools.service */ "./src/services/devtools.service.ts");
const debugger_service_1 = __webpack_require__(/*! @services/debugger.service */ "./src/services/debugger.service.ts");
const chrome_debugger_interface_1 = __webpack_require__(/*! @models/chrome-debugger.interface */ "./src/models/chrome-debugger.interface.ts");
const config_files_service_1 = __webpack_require__(/*! @services/config-files.service */ "./src/services/config-files.service.ts");
const utils_1 = __webpack_require__(/*! ./utils */ "./src/extensions/devtools/utils.ts");
class Devtools {
    constructor() {
        this.panelOpened = false;
        this.devtoolsService = devtools_service_1.DevtoolsService.getInstance();
        this.debuggerService = debugger_service_1.DebuggerService.getInstance();
        this.configFilesService = config_files_service_1.ConfigFilesService.getInstance();
        this.debuggerInstance = {};
        this.devtoolsService
            .createPanel('ONEShop Config Override', '../apps/configuration-override/index.html')
            .then((panel) => this.startListenerWhenPanelOpen(panel));
    }
    static getInstance() {
        if (!this.instance) {
            this.instance = new Devtools();
        }
        return this.instance;
    }
    startListenerWhenPanelOpen(panel) {
        panel.onShown.addListener((panelWindow) => __awaiter(this, void 0, void 0, function* () {
            this.extPanelWindow = panelWindow;
            this.currentTab = yield this.setCurrentTab();
            if (!this.panelOpened) {
                this.panelOpened = true;
                yield this.createDebuggerInstance();
            }
        }));
    }
    setCurrentTab() {
        return new Promise((resolve) => {
            let queryOptions = { active: true, currentWindow: true };
            chrome.tabs.query(queryOptions, (tab) => {
                var _a;
                if (((_a = this.currentTab) === null || _a === void 0 ? void 0 : _a.id) !== tab[0].id) {
                    resolve(tab[0]);
                }
                resolve(undefined);
            });
        });
    }
    createDebuggerInstance() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            this.debuggerInstance = { tabId: (_a = this.currentTab) === null || _a === void 0 ? void 0 : _a.id };
            yield this.debuggerService.attachDebuggerInstance(this.debuggerInstance);
            yield this.debuggerService.enableFetch(this.debuggerInstance, {
                patterns: [{ urlPattern: '*/proxy/ubff?op=getConfigurations' }],
            });
            this.listenForCalls();
        });
    }
    listenForCalls() {
        var _a;
        const setResponseHeaders = (details) => {
            this.responseHeaders = details.responseHeaders;
            return { responseHeaders: this.responseHeaders };
        };
        chrome.webRequest.onHeadersReceived.addListener(setResponseHeaders, {
            tabId: (_a = this.currentTab) === null || _a === void 0 ? void 0 : _a.id,
            urls: ['<all_urls>'],
        }, ['blocking', 'responseHeaders', 'extraHeaders']);
        this.debuggerService.onEvent((source, method, params) => __awaiter(this, void 0, void 0, function* () {
            var _b;
            if (!params) {
                return;
            }
            const { requestId, request } = params;
            const commandParams = {
                requestId,
            };
            if (source.tabId === ((_b = this.currentTab) === null || _b === void 0 ? void 0 : _b.id)) {
                if (method === chrome_debugger_interface_1.DebuggerFetch.requestPaused && request.method !== 'OPTIONS') {
                    yield this.overrideAndSendNewResponse(request, commandParams);
                }
                else {
                    yield this.debuggerService.continueResponse(this.debuggerInstance, commandParams);
                }
            }
        }));
    }
    overrideAndSendNewResponse(request, commandParams) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield this.getResponseBody(request);
            const { variables } = JSON.parse(request.postData);
            const { data } = response.body;
            const configurations = yield this.configFilesService.filterConfigurationsFromObject(variables);
            if (!configurations) {
                return yield this.debuggerService.continueResponse(this.debuggerInstance, commandParams);
            }
            response.body.data = utils_1.replaceConfigurations(data, configurations);
            commandParams.responseCode = 200;
            commandParams.responseHeaders = this.responseHeaders;
            commandParams.body = btoa(unescape(encodeURIComponent(JSON.stringify(response.body))));
            yield this.debuggerService.fulfillRequest(this.debuggerInstance, commandParams);
        });
    }
    getResponseBody(request) {
        return __awaiter(this, void 0, void 0, function* () {
            const { url, method, headers, postData } = request;
            return fetch(url, {
                method,
                mode: 'cors',
                headers,
                redirect: 'follow',
                body: postData,
            }).then((response) => __awaiter(this, void 0, void 0, function* () {
                return {
                    body: yield response.json(),
                    headers: utils_1.getHeaderString(response.headers),
                };
            }));
        });
    }
    destroyDebugger() {
        if (this.debuggerInstance) {
            this.debuggerService.detachDebuggerInstance(this.debuggerInstance);
        }
    }
}
Devtools.getInstance();


/***/ }),

/***/ "./src/extensions/devtools/utils.ts":
/*!******************************************!*\
  !*** ./src/extensions/devtools/utils.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getHeaderString = (headers) => {
    let responseHeader = [];
    headers.forEach((value, name) => {
        responseHeader.push({ name, value });
    });
    return responseHeader;
};
exports.replaceConfigurations = (body, configurations) => {
    configurations.forEach(({ mapValue, file }) => {
        body[mapValue] = file;
    });
    return body;
};


/***/ }),

/***/ "./src/models/chrome-debugger.interface.ts":
/*!*************************************************!*\
  !*** ./src/models/chrome-debugger.interface.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
var DebuggerFetch;
(function (DebuggerFetch) {
    DebuggerFetch["requestPaused"] = "Fetch.requestPaused";
    DebuggerFetch["continueResponse"] = "Fetch.continueResponse";
    DebuggerFetch["fulfillRequest"] = "Fetch.fulfillRequest";
    DebuggerFetch["enable"] = "Fetch.enable";
    DebuggerFetch["getResponseBody"] = "Fetch.getResponseBody";
})(DebuggerFetch = exports.DebuggerFetch || (exports.DebuggerFetch = {}));


/***/ }),

/***/ "./src/services/config-files.service.ts":
/*!**********************************************!*\
  !*** ./src/services/config-files.service.ts ***!
  \**********************************************/
/***/ (function(__unused_webpack_module, exports) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
class ConfigFilesService {
    static getInstance() {
        if (!this.instance) {
            this.instance = new ConfigFilesService();
        }
        return this.instance;
    }
    storeConfigFile(file) {
        return new Promise((resolve) => __awaiter(this, void 0, void 0, function* () {
            let newConfigFiles;
            const currentFiles = yield this.getAllConfigFiles();
            if (currentFiles.some(({ name }) => name === file.name)) {
                newConfigFiles = currentFiles.map((existingFile) => {
                    if (existingFile.name === file.name) {
                        return file;
                    }
                    return existingFile;
                });
            }
            else {
                newConfigFiles = [...currentFiles, file];
            }
            const storageObject = {
                configurations: newConfigFiles,
            };
            chrome.storage.local.set(storageObject, () => {
                resolve(newConfigFiles);
            });
        }));
    }
    removeConfigFile(fileToRemove) {
        return new Promise((resolve) => __awaiter(this, void 0, void 0, function* () {
            const currentFiles = yield this.getAllConfigFiles();
            const filteredConfigFiles = currentFiles === null || currentFiles === void 0 ? void 0 : currentFiles.filter((file) => file.name !== fileToRemove.name);
            const storageObject = {
                configurations: filteredConfigFiles,
            };
            chrome.storage.local.set(storageObject, () => {
                resolve(filteredConfigFiles);
            });
        }));
    }
    getAllConfigFiles() {
        return new Promise((resolve) => {
            chrome.storage.local.get(['configurations'], ({ configurations }) => {
                resolve((configurations === null || configurations === void 0 ? void 0 : configurations.length) ? configurations : []);
            });
        });
    }
    filterConfigurationsFromObject(filter) {
        return new Promise((resolve) => {
            chrome.storage.local.get(['configurations'], ({ configurations }) => {
                const filteredConfigurations = configurations === null || configurations === void 0 ? void 0 : configurations.filter((config) => {
                    return Object.entries(filter).some(([mapValue, configRequested]) => {
                        config.mapValue = mapValue.replace('configName', 'getConfiguration');
                        return configRequested === config.name;
                    });
                });
                resolve((filteredConfigurations === null || filteredConfigurations === void 0 ? void 0 : filteredConfigurations.length) ? filteredConfigurations : undefined);
            });
        });
    }
}
exports.ConfigFilesService = ConfigFilesService;


/***/ }),

/***/ "./src/services/debugger.service.ts":
/*!******************************************!*\
  !*** ./src/services/debugger.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const chrome_debugger_interface_1 = __webpack_require__(/*! @models/chrome-debugger.interface */ "./src/models/chrome-debugger.interface.ts");
/**
 * https://developer.chrome.com/docs/extensions/reference/debugger/
 */
class DebuggerService {
    static getInstance() {
        if (!this.instance) {
            this.instance = new DebuggerService();
        }
        return this.instance;
    }
    attachDebuggerInstance(debuggerInstance) {
        return new Promise((resolve) => {
            chrome.debugger.attach(debuggerInstance, '1.3', () => resolve());
        });
    }
    detachDebuggerInstance(debuggerInstance) {
        return new Promise((resolve) => {
            chrome.debugger.detach(debuggerInstance, () => resolve());
        });
    }
    /**
     *
     * @param debuggerInstance
     * @param method https://chromedevtools.github.io/devtools-protocol/
     * @param commandParams
     */
    sendCommand(debuggerInstance, method, commandParams) {
        return chrome.debugger.sendCommand(debuggerInstance, method, commandParams);
    }
    enableFetch(debuggerInstance, commandParams) {
        return this.sendCommand(debuggerInstance, chrome_debugger_interface_1.DebuggerFetch.enable, commandParams);
    }
    continueResponse(debuggerInstance, commandParams) {
        return chrome.debugger.sendCommand(debuggerInstance, chrome_debugger_interface_1.DebuggerFetch.continueResponse, commandParams);
    }
    fulfillRequest(debuggerInstance, commandParams) {
        return chrome.debugger.sendCommand(debuggerInstance, chrome_debugger_interface_1.DebuggerFetch.fulfillRequest, commandParams);
    }
    onEvent(callback) {
        // @ts-ignore
        chrome.debugger.onEvent.addListener(callback);
    }
}
exports.DebuggerService = DebuggerService;


/***/ }),

/***/ "./src/services/devtools.service.ts":
/*!******************************************!*\
  !*** ./src/services/devtools.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
class DevtoolsService {
    static getInstance() {
        if (!this.instance) {
            this.instance = new DevtoolsService();
        }
        return this.instance;
    }
    createPanel(tabName, pathToHtml) {
        return new Promise((resolve) => {
            chrome.devtools.panels.create(tabName, './assets/images/icon-50.png', pathToHtml, (panel) => {
                resolve(panel);
            });
        });
    }
}
exports.DevtoolsService = DevtoolsService;


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__("./src/extensions/devtools/devtools.ts");
/******/ 	
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9vbmVzaG9wLWNvbmZpZ3VyYXRpb24tb3ZlcnJpZGUvLi9zcmMvZXh0ZW5zaW9ucy9kZXZ0b29scy9kZXZ0b29scy50cyIsIndlYnBhY2s6Ly9vbmVzaG9wLWNvbmZpZ3VyYXRpb24tb3ZlcnJpZGUvLi9zcmMvZXh0ZW5zaW9ucy9kZXZ0b29scy91dGlscy50cyIsIndlYnBhY2s6Ly9vbmVzaG9wLWNvbmZpZ3VyYXRpb24tb3ZlcnJpZGUvLi9zcmMvbW9kZWxzL2Nocm9tZS1kZWJ1Z2dlci5pbnRlcmZhY2UudHMiLCJ3ZWJwYWNrOi8vb25lc2hvcC1jb25maWd1cmF0aW9uLW92ZXJyaWRlLy4vc3JjL3NlcnZpY2VzL2NvbmZpZy1maWxlcy5zZXJ2aWNlLnRzIiwid2VicGFjazovL29uZXNob3AtY29uZmlndXJhdGlvbi1vdmVycmlkZS8uL3NyYy9zZXJ2aWNlcy9kZWJ1Z2dlci5zZXJ2aWNlLnRzIiwid2VicGFjazovL29uZXNob3AtY29uZmlndXJhdGlvbi1vdmVycmlkZS8uL3NyYy9zZXJ2aWNlcy9kZXZ0b29scy5zZXJ2aWNlLnRzIiwid2VicGFjazovL29uZXNob3AtY29uZmlndXJhdGlvbi1vdmVycmlkZS93ZWJwYWNrL2Jvb3RzdHJhcCIsIndlYnBhY2s6Ly9vbmVzaG9wLWNvbmZpZ3VyYXRpb24tb3ZlcnJpZGUvd2VicGFjay9zdGFydHVwIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLHVIQUE2RDtBQUM3RCx1SEFBNkQ7QUFDN0QsOElBQStGO0FBQy9GLG1JQUFvRTtBQUNwRSx5RkFBaUU7QUFLakUsTUFBTSxRQUFRO0lBdUJiO1FBVFEsZ0JBQVcsR0FBRyxLQUFLLENBQUM7UUFVM0IsSUFBSSxDQUFDLGVBQWUsR0FBRyxrQ0FBZSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3JELElBQUksQ0FBQyxlQUFlLEdBQUcsa0NBQWUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUNyRCxJQUFJLENBQUMsa0JBQWtCLEdBQUcseUNBQWtCLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDM0QsSUFBSSxDQUFDLGdCQUFnQixHQUFHLEVBQUUsQ0FBQztRQUMzQixJQUFJLENBQUMsZUFBZTthQUNsQixXQUFXLENBQUMseUJBQXlCLEVBQUUsMkNBQTJDLENBQUM7YUFDbkYsSUFBSSxDQUFDLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsMEJBQTBCLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztJQUMzRCxDQUFDO0lBZkQsTUFBTSxDQUFDLFdBQVc7UUFDakIsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUU7WUFDbkIsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLFFBQVEsRUFBRSxDQUFDO1NBQy9CO1FBQ0QsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDO0lBQ3RCLENBQUM7SUFZRCwwQkFBMEIsQ0FBQyxLQUFxQjtRQUMvQyxLQUFLLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFPLFdBQVcsRUFBRSxFQUFFO1lBQy9DLElBQUksQ0FBQyxjQUFjLEdBQUcsV0FBVyxDQUFDO1lBQ2xDLElBQUksQ0FBQyxVQUFVLEdBQUcsTUFBTSxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDN0MsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUU7Z0JBQ3RCLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDO2dCQUN4QixNQUFNLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO2FBQ3BDO1FBQ0YsQ0FBQyxFQUFDLENBQUM7SUFDSixDQUFDO0lBRUQsYUFBYTtRQUNaLE9BQU8sSUFBSSxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBRTtZQUM5QixJQUFJLFlBQVksR0FBRyxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsYUFBYSxFQUFFLElBQUksRUFBRSxDQUFDO1lBQ3pELE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksRUFBRSxDQUFDLEdBQUcsRUFBRSxFQUFFOztnQkFDdkMsSUFBSSxXQUFJLENBQUMsVUFBVSwwQ0FBRSxFQUFFLE1BQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRTtvQkFDdEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUNoQjtnQkFDRCxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDcEIsQ0FBQyxDQUFDLENBQUM7UUFDSixDQUFDLENBQUMsQ0FBQztJQUNKLENBQUM7SUFFSyxzQkFBc0I7OztZQUMzQixJQUFJLENBQUMsZ0JBQWdCLEdBQUcsRUFBRSxLQUFLLFFBQUUsSUFBSSxDQUFDLFVBQVUsMENBQUUsRUFBRSxFQUFFLENBQUM7WUFDdkQsTUFBTSxJQUFJLENBQUMsZUFBZSxDQUFDLHNCQUFzQixDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1lBQ3pFLE1BQU0sSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLGdCQUFnQixFQUFFO2dCQUM3RCxRQUFRLEVBQUUsQ0FBQyxFQUFFLFVBQVUsRUFBRSxtQ0FBbUMsRUFBRSxDQUFDO2FBQy9ELENBQUMsQ0FBQztZQUNILElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQzs7S0FDdEI7SUFFRCxjQUFjOztRQUNiLE1BQU0sa0JBQWtCLEdBQUcsQ0FBQyxPQUFrQyxFQUFFLEVBQUU7WUFDakUsSUFBSSxDQUFDLGVBQWUsR0FBRyxPQUFPLENBQUMsZUFBZSxDQUFDO1lBQy9DLE9BQU8sRUFBRSxlQUFlLEVBQUUsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBQ2xELENBQUMsQ0FBQztRQUNGLE1BQU0sQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsV0FBVyxDQUM5QyxrQkFBa0IsRUFDbEI7WUFDQyxLQUFLLFFBQUUsSUFBSSxDQUFDLFVBQVUsMENBQUUsRUFBRTtZQUMxQixJQUFJLEVBQUUsQ0FBQyxZQUFZLENBQUM7U0FDcEIsRUFDRCxDQUFDLFVBQVUsRUFBRSxpQkFBaUIsRUFBRSxjQUFjLENBQUMsQ0FDL0MsQ0FBQztRQUVGLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLENBQU8sTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsRUFBRTs7WUFDN0QsSUFBSSxDQUFDLE1BQU0sRUFBRTtnQkFDWixPQUFPO2FBQ1A7WUFDRCxNQUFNLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxHQUFHLE1BQU0sQ0FBQztZQUN0QyxNQUFNLGFBQWEsR0FBUTtnQkFDMUIsU0FBUzthQUNULENBQUM7WUFFRixJQUFJLE1BQU0sQ0FBQyxLQUFLLFlBQUssSUFBSSxDQUFDLFVBQVUsMENBQUUsRUFBRSxHQUFFO2dCQUN6QyxJQUFJLE1BQU0sS0FBSyx5Q0FBYSxDQUFDLGFBQWEsSUFBSSxPQUFPLENBQUMsTUFBTSxLQUFLLFNBQVMsRUFBRTtvQkFDM0UsTUFBTSxJQUFJLENBQUMsMEJBQTBCLENBQUMsT0FBTyxFQUFFLGFBQWEsQ0FBQyxDQUFDO2lCQUM5RDtxQkFBTTtvQkFDTixNQUFNLElBQUksQ0FBQyxlQUFlLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLGdCQUFnQixFQUFFLGFBQWEsQ0FBQyxDQUFDO2lCQUNsRjthQUNEO1FBQ0YsQ0FBQyxFQUFDLENBQUM7SUFDSixDQUFDO0lBRUssMEJBQTBCLENBQUMsT0FBK0IsRUFBRSxhQUFrQzs7WUFDbkcsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ3JELE1BQU0sRUFBRSxTQUFTLEVBQUUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUNuRCxNQUFNLEVBQUUsSUFBSSxFQUFFLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQztZQUUvQixNQUFNLGNBQWMsR0FBRyxNQUFNLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyw4QkFBOEIsQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUUvRixJQUFJLENBQUMsY0FBYyxFQUFFO2dCQUNwQixPQUFPLE1BQU0sSUFBSSxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsYUFBYSxDQUFDLENBQUM7YUFDekY7WUFFRCxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyw2QkFBcUIsQ0FBQyxJQUFJLEVBQUUsY0FBYyxDQUFDLENBQUM7WUFFakUsYUFBYSxDQUFDLFlBQVksR0FBRyxHQUFHLENBQUM7WUFDakMsYUFBYSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDO1lBQ3JELGFBQWEsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUV2RixNQUFNLElBQUksQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxhQUFhLENBQUMsQ0FBQztRQUNqRixDQUFDO0tBQUE7SUFFSyxlQUFlLENBQUMsT0FBK0I7O1lBQ3BELE1BQU0sRUFBRSxHQUFHLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsR0FBRyxPQUFPLENBQUM7WUFDbkQsT0FBTyxLQUFLLENBQUMsR0FBRyxFQUFFO2dCQUNqQixNQUFNO2dCQUNOLElBQUksRUFBRSxNQUFNO2dCQUNaLE9BQU87Z0JBQ1AsUUFBUSxFQUFFLFFBQVE7Z0JBQ2xCLElBQUksRUFBRSxRQUFRO2FBQ2QsQ0FBQyxDQUFDLElBQUksQ0FDTixDQUFPLFFBQWtCLEVBQTJCLEVBQUU7Z0JBQ3JELE9BQU87b0JBQ04sSUFBSSxFQUFFLE1BQU0sUUFBUSxDQUFDLElBQUksRUFBRTtvQkFDM0IsT0FBTyxFQUFFLHVCQUFlLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQztpQkFDMUMsQ0FBQztZQUNILENBQUMsRUFDRCxDQUFDO1FBQ0gsQ0FBQztLQUFBO0lBRUQsZUFBZTtRQUNkLElBQUksSUFBSSxDQUFDLGdCQUFnQixFQUFFO1lBQzFCLElBQUksQ0FBQyxlQUFlLENBQUMsc0JBQXNCLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7U0FDbkU7SUFDRixDQUFDO0NBQ0Q7QUFFRCxRQUFRLENBQUMsV0FBVyxFQUFFLENBQUM7Ozs7Ozs7Ozs7Ozs7QUNySlYsdUJBQWUsR0FBRyxDQUFDLE9BQWdCLEVBQTZCLEVBQUU7SUFDOUUsSUFBSSxjQUFjLEdBQThCLEVBQUUsQ0FBQztJQUNuRCxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxFQUFFLElBQUksRUFBRSxFQUFFO1FBQy9CLGNBQWMsQ0FBQyxJQUFJLENBQUMsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQztJQUN0QyxDQUFDLENBQUMsQ0FBQztJQUNILE9BQU8sY0FBYyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQztBQUVXLDZCQUFxQixHQUFHLENBQ3BDLElBQXlCLEVBQ3pCLGNBQTZCLEVBQ1AsRUFBRTtJQUN4QixjQUFjLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRTtRQUM3QyxJQUFJLENBQUMsUUFBa0IsQ0FBQyxHQUFHLElBQUksQ0FBQztJQUNqQyxDQUFDLENBQUMsQ0FBQztJQUNILE9BQU8sSUFBSSxDQUFDO0FBQ2IsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7O0FDTUYsSUFBWSxhQU1YO0FBTkQsV0FBWSxhQUFhO0lBQ3hCLHNEQUFxQztJQUNyQyw0REFBMkM7SUFDM0Msd0RBQXVDO0lBQ3ZDLHdDQUF1QjtJQUN2QiwwREFBeUM7QUFDMUMsQ0FBQyxFQU5XLGFBQWEsR0FBYixxQkFBYSxLQUFiLHFCQUFhLFFBTXhCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDNUJELE1BQWEsa0JBQWtCO0lBRzlCLE1BQU0sQ0FBQyxXQUFXO1FBQ2pCLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ25CLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxrQkFBa0IsRUFBRSxDQUFDO1NBQ3pDO1FBQ0QsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDO0lBQ3RCLENBQUM7SUFFTSxlQUFlLENBQUMsSUFBaUI7UUFDdkMsT0FBTyxJQUFJLE9BQU8sQ0FBQyxDQUFPLE9BQU8sRUFBRSxFQUFFO1lBQ3BDLElBQUksY0FBNkIsQ0FBQztZQUNsQyxNQUFNLFlBQVksR0FBRyxNQUFNLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1lBQ3BELElBQUksWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxDQUFDLElBQUksS0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQ3hELGNBQWMsR0FBRyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUMsWUFBWSxFQUFFLEVBQUU7b0JBQ2xELElBQUksWUFBWSxDQUFDLElBQUksS0FBSyxJQUFJLENBQUMsSUFBSSxFQUFFO3dCQUNwQyxPQUFPLElBQUksQ0FBQztxQkFDWjtvQkFDRCxPQUFPLFlBQVksQ0FBQztnQkFDckIsQ0FBQyxDQUFDLENBQUM7YUFDSDtpQkFBTTtnQkFDTixjQUFjLEdBQUcsQ0FBQyxHQUFHLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQzthQUN6QztZQUVELE1BQU0sYUFBYSxHQUFtQjtnQkFDckMsY0FBYyxFQUFFLGNBQWM7YUFDOUIsQ0FBQztZQUNGLE1BQU0sQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsR0FBRyxFQUFFO2dCQUM1QyxPQUFPLENBQUMsY0FBYyxDQUFDLENBQUM7WUFDekIsQ0FBQyxDQUFDLENBQUM7UUFDSixDQUFDLEVBQUMsQ0FBQztJQUNKLENBQUM7SUFFTSxnQkFBZ0IsQ0FBQyxZQUF5QjtRQUNoRCxPQUFPLElBQUksT0FBTyxDQUFDLENBQU8sT0FBTyxFQUFFLEVBQUU7WUFDcEMsTUFBTSxZQUFZLEdBQUcsTUFBTSxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztZQUNwRCxNQUFNLG1CQUFtQixHQUFHLFlBQVksYUFBWixZQUFZLHVCQUFaLFlBQVksQ0FBRSxNQUFNLENBQUMsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLEtBQUssWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzVGLE1BQU0sYUFBYSxHQUFtQjtnQkFDckMsY0FBYyxFQUFFLG1CQUFtQjthQUNuQyxDQUFDO1lBQ0YsTUFBTSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxHQUFHLEVBQUU7Z0JBQzVDLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1lBQzlCLENBQUMsQ0FBQyxDQUFDO1FBQ0osQ0FBQyxFQUFDLENBQUM7SUFDSixDQUFDO0lBRU0saUJBQWlCO1FBQ3ZCLE9BQU8sSUFBSSxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBRTtZQUM5QixNQUFNLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLENBQUMsRUFBRSxjQUFjLEVBQUUsRUFBRSxFQUFFO2dCQUNuRSxPQUFPLENBQUMsZUFBYyxhQUFkLGNBQWMsdUJBQWQsY0FBYyxDQUFFLE1BQU0sRUFBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUN2RCxDQUFDLENBQUMsQ0FBQztRQUNKLENBQUMsQ0FBQyxDQUFDO0lBQ0osQ0FBQztJQUVELDhCQUE4QixDQUFDLE1BQTJCO1FBQ3pELE9BQU8sSUFBSSxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBRTtZQUM5QixNQUFNLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLENBQUMsRUFBRSxjQUFjLEVBQUUsRUFBRSxFQUFFO2dCQUNuRSxNQUFNLHNCQUFzQixHQUFHLGNBQWMsYUFBZCxjQUFjLHVCQUFkLGNBQWMsQ0FBRSxNQUFNLENBQUMsQ0FBQyxNQUFtQixFQUFFLEVBQUU7b0JBQzdFLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxlQUFlLENBQUMsRUFBRSxFQUFFO3dCQUNsRSxNQUFNLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQyxPQUFPLENBQUMsWUFBWSxFQUFFLGtCQUFrQixDQUFDLENBQUM7d0JBQ3JFLE9BQU8sZUFBZSxLQUFLLE1BQU0sQ0FBQyxJQUFJLENBQUM7b0JBQ3hDLENBQUMsQ0FBQyxDQUFDO2dCQUNKLENBQUMsQ0FBQyxDQUFDO2dCQUNILE9BQU8sQ0FBQyx1QkFBc0IsYUFBdEIsc0JBQXNCLHVCQUF0QixzQkFBc0IsQ0FBRSxNQUFNLEVBQUMsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUM5RSxDQUFDLENBQUMsQ0FBQztRQUNKLENBQUMsQ0FBQyxDQUFDO0lBQ0osQ0FBQztDQUNEO0FBcEVELGdEQW9FQzs7Ozs7Ozs7Ozs7OztBQ3ZFRCw4SUFBK0U7QUFFL0U7O0dBRUc7QUFDSCxNQUFhLGVBQWU7SUFHM0IsTUFBTSxDQUFDLFdBQVc7UUFDakIsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUU7WUFDbkIsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLGVBQWUsRUFBRSxDQUFDO1NBQ3RDO1FBQ0QsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDO0lBQ3RCLENBQUM7SUFFRCxzQkFBc0IsQ0FBQyxnQkFBMEM7UUFDaEUsT0FBTyxJQUFJLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFFO1lBQzlCLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLGdCQUFnQixFQUFFLEtBQUssRUFBRSxHQUFHLEVBQUUsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1FBQ2xFLENBQUMsQ0FBQyxDQUFDO0lBQ0osQ0FBQztJQUVELHNCQUFzQixDQUFDLGdCQUEwQztRQUNoRSxPQUFPLElBQUksT0FBTyxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQUU7WUFDOUIsTUFBTSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsR0FBRyxFQUFFLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztRQUMzRCxDQUFDLENBQUMsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNLLFdBQVcsQ0FDbEIsZ0JBQTBDLEVBQzFDLE1BQXFCLEVBQ3JCLGFBQXNCO1FBRXRCLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsZ0JBQWdCLEVBQUUsTUFBTSxFQUFFLGFBQWEsQ0FBQyxDQUFDO0lBQzdFLENBQUM7SUFFRCxXQUFXLENBQUMsZ0JBQTBDLEVBQUUsYUFBc0I7UUFDN0UsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLGdCQUFnQixFQUFFLHlDQUFhLENBQUMsTUFBTSxFQUFFLGFBQWEsQ0FBQyxDQUFDO0lBQ2hGLENBQUM7SUFFRCxnQkFBZ0IsQ0FBQyxnQkFBMEMsRUFBRSxhQUFxQjtRQUNqRixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLGdCQUFnQixFQUFFLHlDQUFhLENBQUMsZ0JBQWdCLEVBQUUsYUFBYSxDQUFDLENBQUM7SUFDckcsQ0FBQztJQUVELGNBQWMsQ0FBQyxnQkFBMEMsRUFBRSxhQUFxQjtRQUMvRSxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLGdCQUFnQixFQUFFLHlDQUFhLENBQUMsY0FBYyxFQUFFLGFBQWEsQ0FBQyxDQUFDO0lBQ25HLENBQUM7SUFFRCxPQUFPLENBQUMsUUFBMEY7UUFDakcsYUFBYTtRQUNiLE1BQU0sQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUMvQyxDQUFDO0NBQ0Q7QUFwREQsMENBb0RDOzs7Ozs7Ozs7Ozs7O0FDdkRELE1BQWEsZUFBZTtJQUczQixNQUFNLENBQUMsV0FBVztRQUNqQixJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNuQixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksZUFBZSxFQUFFLENBQUM7U0FDdEM7UUFDRCxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUM7SUFDdEIsQ0FBQztJQUVELFdBQVcsQ0FBQyxPQUFlLEVBQUUsVUFBa0I7UUFDOUMsT0FBTyxJQUFJLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFFO1lBQzlCLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUUsNkJBQTZCLEVBQUUsVUFBVSxFQUFFLENBQUMsS0FBSyxFQUFFLEVBQUU7Z0JBQzNGLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNoQixDQUFDLENBQUMsQ0FBQztRQUNKLENBQUMsQ0FBQyxDQUFDO0lBQ0osQ0FBQztDQUNEO0FBakJELDBDQWlCQzs7Ozs7OztVQ25CRDtVQUNBOztVQUVBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBOztVQUVBO1VBQ0E7O1VBRUE7VUFDQTtVQUNBOzs7O1VDdEJBO1VBQ0E7VUFDQTtVQUNBIiwiZmlsZSI6ImV4dGVuc2lvbnMvZGV2dG9vbHMuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBEZXZ0b29sc1NlcnZpY2UgfSBmcm9tICdAc2VydmljZXMvZGV2dG9vbHMuc2VydmljZSc7XG5pbXBvcnQgeyBEZWJ1Z2dlclNlcnZpY2UgfSBmcm9tICdAc2VydmljZXMvZGVidWdnZXIuc2VydmljZSc7XG5pbXBvcnQgeyBDb25maWdSZXNwb25zZSwgRGVidWdnZXJGZXRjaCwgRXZlbnRQYXJhbXMgfSBmcm9tICdAbW9kZWxzL2Nocm9tZS1kZWJ1Z2dlci5pbnRlcmZhY2UnO1xuaW1wb3J0IHsgQ29uZmlnRmlsZXNTZXJ2aWNlIH0gZnJvbSAnQHNlcnZpY2VzL2NvbmZpZy1maWxlcy5zZXJ2aWNlJztcbmltcG9ydCB7IGdldEhlYWRlclN0cmluZywgcmVwbGFjZUNvbmZpZ3VyYXRpb25zIH0gZnJvbSAnLi91dGlscyc7XG5pbXBvcnQgRXh0ZW5zaW9uUGFuZWwgPSBjaHJvbWUuZGV2dG9vbHMucGFuZWxzLkV4dGVuc2lvblBhbmVsO1xuaW1wb3J0IEh0dHBIZWFkZXIgPSBjaHJvbWUud2ViUmVxdWVzdC5IdHRwSGVhZGVyO1xuaW1wb3J0IFdlYlJlc3BvbnNlSGVhZGVyc0RldGFpbHMgPSBjaHJvbWUud2ViUmVxdWVzdC5XZWJSZXNwb25zZUhlYWRlcnNEZXRhaWxzO1xuXG5jbGFzcyBEZXZ0b29scyB7XG5cdHByaXZhdGUgc3RhdGljIGluc3RhbmNlOiBEZXZ0b29scztcblxuXHRwcml2YXRlIGRldnRvb2xzU2VydmljZTogRGV2dG9vbHNTZXJ2aWNlO1xuXHRwcml2YXRlIGRlYnVnZ2VyU2VydmljZTogRGVidWdnZXJTZXJ2aWNlO1xuXHRwcml2YXRlIGNvbmZpZ0ZpbGVzU2VydmljZTogQ29uZmlnRmlsZXNTZXJ2aWNlO1xuXG5cdHByaXZhdGUgZGVidWdnZXJJbnN0YW5jZTogY2hyb21lLmRlYnVnZ2VyLkRlYnVnZ2VlO1xuXG5cdHByaXZhdGUgZXh0UGFuZWxXaW5kb3c6IFdpbmRvdyB8IHVuZGVmaW5lZDtcblx0cHJpdmF0ZSBjdXJyZW50VGFiOiBjaHJvbWUudGFicy5UYWIgfCB1bmRlZmluZWQ7XG5cblx0cHJpdmF0ZSByZXNwb25zZUhlYWRlcnM6IEh0dHBIZWFkZXJbXSB8IHVuZGVmaW5lZDtcblxuXHRwcml2YXRlIHBhbmVsT3BlbmVkID0gZmFsc2U7XG5cblx0c3RhdGljIGdldEluc3RhbmNlKCkge1xuXHRcdGlmICghdGhpcy5pbnN0YW5jZSkge1xuXHRcdFx0dGhpcy5pbnN0YW5jZSA9IG5ldyBEZXZ0b29scygpO1xuXHRcdH1cblx0XHRyZXR1cm4gdGhpcy5pbnN0YW5jZTtcblx0fVxuXG5cdGNvbnN0cnVjdG9yKCkge1xuXHRcdHRoaXMuZGV2dG9vbHNTZXJ2aWNlID0gRGV2dG9vbHNTZXJ2aWNlLmdldEluc3RhbmNlKCk7XG5cdFx0dGhpcy5kZWJ1Z2dlclNlcnZpY2UgPSBEZWJ1Z2dlclNlcnZpY2UuZ2V0SW5zdGFuY2UoKTtcblx0XHR0aGlzLmNvbmZpZ0ZpbGVzU2VydmljZSA9IENvbmZpZ0ZpbGVzU2VydmljZS5nZXRJbnN0YW5jZSgpO1xuXHRcdHRoaXMuZGVidWdnZXJJbnN0YW5jZSA9IHt9O1xuXHRcdHRoaXMuZGV2dG9vbHNTZXJ2aWNlXG5cdFx0XHQuY3JlYXRlUGFuZWwoJ09ORVNob3AgQ29uZmlnIE92ZXJyaWRlJywgJy4uL2FwcHMvY29uZmlndXJhdGlvbi1vdmVycmlkZS9pbmRleC5odG1sJylcblx0XHRcdC50aGVuKChwYW5lbCkgPT4gdGhpcy5zdGFydExpc3RlbmVyV2hlblBhbmVsT3BlbihwYW5lbCkpO1xuXHR9XG5cblx0c3RhcnRMaXN0ZW5lcldoZW5QYW5lbE9wZW4ocGFuZWw6IEV4dGVuc2lvblBhbmVsKTogdm9pZCB7XG5cdFx0cGFuZWwub25TaG93bi5hZGRMaXN0ZW5lcihhc3luYyAocGFuZWxXaW5kb3cpID0+IHtcblx0XHRcdHRoaXMuZXh0UGFuZWxXaW5kb3cgPSBwYW5lbFdpbmRvdztcblx0XHRcdHRoaXMuY3VycmVudFRhYiA9IGF3YWl0IHRoaXMuc2V0Q3VycmVudFRhYigpO1xuXHRcdFx0aWYgKCF0aGlzLnBhbmVsT3BlbmVkKSB7XG5cdFx0XHRcdHRoaXMucGFuZWxPcGVuZWQgPSB0cnVlO1xuXHRcdFx0XHRhd2FpdCB0aGlzLmNyZWF0ZURlYnVnZ2VySW5zdGFuY2UoKTtcblx0XHRcdH1cblx0XHR9KTtcblx0fVxuXG5cdHNldEN1cnJlbnRUYWIoKTogUHJvbWlzZTxjaHJvbWUudGFicy5UYWIgfCB1bmRlZmluZWQ+IHtcblx0XHRyZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcblx0XHRcdGxldCBxdWVyeU9wdGlvbnMgPSB7IGFjdGl2ZTogdHJ1ZSwgY3VycmVudFdpbmRvdzogdHJ1ZSB9O1xuXHRcdFx0Y2hyb21lLnRhYnMucXVlcnkocXVlcnlPcHRpb25zLCAodGFiKSA9PiB7XG5cdFx0XHRcdGlmICh0aGlzLmN1cnJlbnRUYWI/LmlkICE9PSB0YWJbMF0uaWQpIHtcblx0XHRcdFx0XHRyZXNvbHZlKHRhYlswXSk7XG5cdFx0XHRcdH1cblx0XHRcdFx0cmVzb2x2ZSh1bmRlZmluZWQpO1xuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH1cblxuXHRhc3luYyBjcmVhdGVEZWJ1Z2dlckluc3RhbmNlKCkge1xuXHRcdHRoaXMuZGVidWdnZXJJbnN0YW5jZSA9IHsgdGFiSWQ6IHRoaXMuY3VycmVudFRhYj8uaWQgfTtcblx0XHRhd2FpdCB0aGlzLmRlYnVnZ2VyU2VydmljZS5hdHRhY2hEZWJ1Z2dlckluc3RhbmNlKHRoaXMuZGVidWdnZXJJbnN0YW5jZSk7XG5cdFx0YXdhaXQgdGhpcy5kZWJ1Z2dlclNlcnZpY2UuZW5hYmxlRmV0Y2godGhpcy5kZWJ1Z2dlckluc3RhbmNlLCB7XG5cdFx0XHRwYXR0ZXJuczogW3sgdXJsUGF0dGVybjogJyovcHJveHkvdWJmZj9vcD1nZXRDb25maWd1cmF0aW9ucycgfV0sXG5cdFx0fSk7XG5cdFx0dGhpcy5saXN0ZW5Gb3JDYWxscygpO1xuXHR9XG5cblx0bGlzdGVuRm9yQ2FsbHMoKSB7XG5cdFx0Y29uc3Qgc2V0UmVzcG9uc2VIZWFkZXJzID0gKGRldGFpbHM6IFdlYlJlc3BvbnNlSGVhZGVyc0RldGFpbHMpID0+IHtcblx0XHRcdHRoaXMucmVzcG9uc2VIZWFkZXJzID0gZGV0YWlscy5yZXNwb25zZUhlYWRlcnM7XG5cdFx0XHRyZXR1cm4geyByZXNwb25zZUhlYWRlcnM6IHRoaXMucmVzcG9uc2VIZWFkZXJzIH07XG5cdFx0fTtcblx0XHRjaHJvbWUud2ViUmVxdWVzdC5vbkhlYWRlcnNSZWNlaXZlZC5hZGRMaXN0ZW5lcihcblx0XHRcdHNldFJlc3BvbnNlSGVhZGVycyxcblx0XHRcdHtcblx0XHRcdFx0dGFiSWQ6IHRoaXMuY3VycmVudFRhYj8uaWQsXG5cdFx0XHRcdHVybHM6IFsnPGFsbF91cmxzPiddLFxuXHRcdFx0fSxcblx0XHRcdFsnYmxvY2tpbmcnLCAncmVzcG9uc2VIZWFkZXJzJywgJ2V4dHJhSGVhZGVycyddXG5cdFx0KTtcblxuXHRcdHRoaXMuZGVidWdnZXJTZXJ2aWNlLm9uRXZlbnQoYXN5bmMgKHNvdXJjZSwgbWV0aG9kLCBwYXJhbXMpID0+IHtcblx0XHRcdGlmICghcGFyYW1zKSB7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblx0XHRcdGNvbnN0IHsgcmVxdWVzdElkLCByZXF1ZXN0IH0gPSBwYXJhbXM7XG5cdFx0XHRjb25zdCBjb21tYW5kUGFyYW1zOiBhbnkgPSB7XG5cdFx0XHRcdHJlcXVlc3RJZCxcblx0XHRcdH07XG5cblx0XHRcdGlmIChzb3VyY2UudGFiSWQgPT09IHRoaXMuY3VycmVudFRhYj8uaWQpIHtcblx0XHRcdFx0aWYgKG1ldGhvZCA9PT0gRGVidWdnZXJGZXRjaC5yZXF1ZXN0UGF1c2VkICYmIHJlcXVlc3QubWV0aG9kICE9PSAnT1BUSU9OUycpIHtcblx0XHRcdFx0XHRhd2FpdCB0aGlzLm92ZXJyaWRlQW5kU2VuZE5ld1Jlc3BvbnNlKHJlcXVlc3QsIGNvbW1hbmRQYXJhbXMpO1xuXHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdGF3YWl0IHRoaXMuZGVidWdnZXJTZXJ2aWNlLmNvbnRpbnVlUmVzcG9uc2UodGhpcy5kZWJ1Z2dlckluc3RhbmNlLCBjb21tYW5kUGFyYW1zKTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH0pO1xuXHR9XG5cblx0YXN5bmMgb3ZlcnJpZGVBbmRTZW5kTmV3UmVzcG9uc2UocmVxdWVzdDogRXZlbnRQYXJhbXNbJ3JlcXVlc3QnXSwgY29tbWFuZFBhcmFtczogUmVjb3JkPHN0cmluZywgYW55Pikge1xuXHRcdGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgdGhpcy5nZXRSZXNwb25zZUJvZHkocmVxdWVzdCk7XG5cdFx0Y29uc3QgeyB2YXJpYWJsZXMgfSA9IEpTT04ucGFyc2UocmVxdWVzdC5wb3N0RGF0YSk7XG5cdFx0Y29uc3QgeyBkYXRhIH0gPSByZXNwb25zZS5ib2R5O1xuXG5cdFx0Y29uc3QgY29uZmlndXJhdGlvbnMgPSBhd2FpdCB0aGlzLmNvbmZpZ0ZpbGVzU2VydmljZS5maWx0ZXJDb25maWd1cmF0aW9uc0Zyb21PYmplY3QodmFyaWFibGVzKTtcblxuXHRcdGlmICghY29uZmlndXJhdGlvbnMpIHtcblx0XHRcdHJldHVybiBhd2FpdCB0aGlzLmRlYnVnZ2VyU2VydmljZS5jb250aW51ZVJlc3BvbnNlKHRoaXMuZGVidWdnZXJJbnN0YW5jZSwgY29tbWFuZFBhcmFtcyk7XG5cdFx0fVxuXG5cdFx0cmVzcG9uc2UuYm9keS5kYXRhID0gcmVwbGFjZUNvbmZpZ3VyYXRpb25zKGRhdGEsIGNvbmZpZ3VyYXRpb25zKTtcblxuXHRcdGNvbW1hbmRQYXJhbXMucmVzcG9uc2VDb2RlID0gMjAwO1xuXHRcdGNvbW1hbmRQYXJhbXMucmVzcG9uc2VIZWFkZXJzID0gdGhpcy5yZXNwb25zZUhlYWRlcnM7XG5cdFx0Y29tbWFuZFBhcmFtcy5ib2R5ID0gYnRvYSh1bmVzY2FwZShlbmNvZGVVUklDb21wb25lbnQoSlNPTi5zdHJpbmdpZnkocmVzcG9uc2UuYm9keSkpKSk7XG5cblx0XHRhd2FpdCB0aGlzLmRlYnVnZ2VyU2VydmljZS5mdWxmaWxsUmVxdWVzdCh0aGlzLmRlYnVnZ2VySW5zdGFuY2UsIGNvbW1hbmRQYXJhbXMpO1xuXHR9XG5cblx0YXN5bmMgZ2V0UmVzcG9uc2VCb2R5KHJlcXVlc3Q6IEV2ZW50UGFyYW1zWydyZXF1ZXN0J10pOiBQcm9taXNlPENvbmZpZ1Jlc3BvbnNlPiB7XG5cdFx0Y29uc3QgeyB1cmwsIG1ldGhvZCwgaGVhZGVycywgcG9zdERhdGEgfSA9IHJlcXVlc3Q7XG5cdFx0cmV0dXJuIGZldGNoKHVybCwge1xuXHRcdFx0bWV0aG9kLFxuXHRcdFx0bW9kZTogJ2NvcnMnLFxuXHRcdFx0aGVhZGVycyxcblx0XHRcdHJlZGlyZWN0OiAnZm9sbG93Jyxcblx0XHRcdGJvZHk6IHBvc3REYXRhLFxuXHRcdH0pLnRoZW4oXG5cdFx0XHRhc3luYyAocmVzcG9uc2U6IFJlc3BvbnNlKTogUHJvbWlzZTxDb25maWdSZXNwb25zZT4gPT4ge1xuXHRcdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRcdGJvZHk6IGF3YWl0IHJlc3BvbnNlLmpzb24oKSxcblx0XHRcdFx0XHRoZWFkZXJzOiBnZXRIZWFkZXJTdHJpbmcocmVzcG9uc2UuaGVhZGVycyksXG5cdFx0XHRcdH07XG5cdFx0XHR9XG5cdFx0KTtcblx0fVxuXG5cdGRlc3Ryb3lEZWJ1Z2dlcigpIHtcblx0XHRpZiAodGhpcy5kZWJ1Z2dlckluc3RhbmNlKSB7XG5cdFx0XHR0aGlzLmRlYnVnZ2VyU2VydmljZS5kZXRhY2hEZWJ1Z2dlckluc3RhbmNlKHRoaXMuZGVidWdnZXJJbnN0YW5jZSk7XG5cdFx0fVxuXHR9XG59XG5cbkRldnRvb2xzLmdldEluc3RhbmNlKCk7XG4iLCJpbXBvcnQgeyBDb25maWdSZXNwb25zZSB9IGZyb20gJ0Btb2RlbHMvY2hyb21lLWRlYnVnZ2VyLmludGVyZmFjZSc7XG5pbXBvcnQgeyBJQ29uZmlnRmlsZSB9IGZyb20gJ0Btb2RlbHMvY29uZmlnLWZpbGUuaW50ZXJmYWNlJztcblxuZXhwb3J0IGNvbnN0IGdldEhlYWRlclN0cmluZyA9IChoZWFkZXJzOiBIZWFkZXJzKTogQ29uZmlnUmVzcG9uc2VbJ2hlYWRlcnMnXSA9PiB7XG5cdGxldCByZXNwb25zZUhlYWRlcjogQ29uZmlnUmVzcG9uc2VbJ2hlYWRlcnMnXSA9IFtdO1xuXHRoZWFkZXJzLmZvckVhY2goKHZhbHVlLCBuYW1lKSA9PiB7XG5cdFx0cmVzcG9uc2VIZWFkZXIucHVzaCh7IG5hbWUsIHZhbHVlIH0pO1xuXHR9KTtcblx0cmV0dXJuIHJlc3BvbnNlSGVhZGVyO1xufTtcblxuZXhwb3J0IGNvbnN0IHJlcGxhY2VDb25maWd1cmF0aW9ucyA9IChcblx0Ym9keTogUmVjb3JkPHN0cmluZywgYW55Pixcblx0Y29uZmlndXJhdGlvbnM6IElDb25maWdGaWxlW11cbik6IFJlY29yZDxzdHJpbmcsIGFueT4gPT4ge1xuXHRjb25maWd1cmF0aW9ucy5mb3JFYWNoKCh7IG1hcFZhbHVlLCBmaWxlIH0pID0+IHtcblx0XHRib2R5W21hcFZhbHVlIGFzIHN0cmluZ10gPSBmaWxlO1xuXHR9KTtcblx0cmV0dXJuIGJvZHk7XG59O1xuIiwiaW50ZXJmYWNlIFJlcXVlc3Qge1xuXHRoZWFkZXJzOiBSZWNvcmQ8c3RyaW5nLCBhbnk+O1xuXHRpbml0aWFsUHJpb3JpdHk6ICdIaWdoJyB8ICdMb3cnO1xuXHRtZXRob2Q6ICdPUFRJT05TJyB8ICdQT1NUJyB8ICdHRVQnIHwgJ1BBVENIJyB8ICdERUxFVEUnIHwgJ1BVVCc7XG5cdHJlZmVycmVyUG9saWN5OiBzdHJpbmc7XG5cdHVybDogc3RyaW5nO1xuXHRwb3N0RGF0YTogc3RyaW5nO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIENvbmZpZ1Jlc3BvbnNlIHtcblx0aGVhZGVyczogeyBuYW1lOiBzdHJpbmc7IHZhbHVlOiBzdHJpbmcgfVtdO1xuXHRib2R5OiB7XG5cdFx0ZGF0YTogUmVjb3JkPHN0cmluZywgYW55Pjtcblx0XHRlcnJvcnM/OiBSZWNvcmQ8c3RyaW5nLCBhbnk+W107XG5cdH07XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgRXZlbnRQYXJhbXMge1xuXHRmcmFtZUlkOiBzdHJpbmc7XG5cdG5ldHdvcmtJZDogc3RyaW5nO1xuXHRyZXF1ZXN0OiBSZXF1ZXN0O1xuXHRyZXF1ZXN0SWQ6IHN0cmluZztcblx0cmVzb3VyY2VUeXBlOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBlbnVtIERlYnVnZ2VyRmV0Y2gge1xuXHRyZXF1ZXN0UGF1c2VkID0gJ0ZldGNoLnJlcXVlc3RQYXVzZWQnLFxuXHRjb250aW51ZVJlc3BvbnNlID0gJ0ZldGNoLmNvbnRpbnVlUmVzcG9uc2UnLFxuXHRmdWxmaWxsUmVxdWVzdCA9ICdGZXRjaC5mdWxmaWxsUmVxdWVzdCcsXG5cdGVuYWJsZSA9ICdGZXRjaC5lbmFibGUnLFxuXHRnZXRSZXNwb25zZUJvZHkgPSAnRmV0Y2guZ2V0UmVzcG9uc2VCb2R5Jyxcbn1cbiIsImltcG9ydCB7IElDb25maWdGaWxlIH0gZnJvbSAnQG1vZGVscy9jb25maWctZmlsZS5pbnRlcmZhY2UnO1xuaW1wb3J0IHsgSUNocm9tZVN0b3JhZ2UgfSBmcm9tICdAbW9kZWxzL2Nocm9tZS1zdG9yYWdlLmludGVyZmFjZSc7XG5cbmV4cG9ydCBjbGFzcyBDb25maWdGaWxlc1NlcnZpY2Uge1xuXHRwcml2YXRlIHN0YXRpYyBpbnN0YW5jZTogQ29uZmlnRmlsZXNTZXJ2aWNlO1xuXG5cdHN0YXRpYyBnZXRJbnN0YW5jZSgpIHtcblx0XHRpZiAoIXRoaXMuaW5zdGFuY2UpIHtcblx0XHRcdHRoaXMuaW5zdGFuY2UgPSBuZXcgQ29uZmlnRmlsZXNTZXJ2aWNlKCk7XG5cdFx0fVxuXHRcdHJldHVybiB0aGlzLmluc3RhbmNlO1xuXHR9XG5cblx0cHVibGljIHN0b3JlQ29uZmlnRmlsZShmaWxlOiBJQ29uZmlnRmlsZSk6IFByb21pc2U8SUNvbmZpZ0ZpbGVbXT4ge1xuXHRcdHJldHVybiBuZXcgUHJvbWlzZShhc3luYyAocmVzb2x2ZSkgPT4ge1xuXHRcdFx0bGV0IG5ld0NvbmZpZ0ZpbGVzOiBJQ29uZmlnRmlsZVtdO1xuXHRcdFx0Y29uc3QgY3VycmVudEZpbGVzID0gYXdhaXQgdGhpcy5nZXRBbGxDb25maWdGaWxlcygpO1xuXHRcdFx0aWYgKGN1cnJlbnRGaWxlcy5zb21lKCh7IG5hbWUgfSkgPT4gbmFtZSA9PT0gZmlsZS5uYW1lKSkge1xuXHRcdFx0XHRuZXdDb25maWdGaWxlcyA9IGN1cnJlbnRGaWxlcy5tYXAoKGV4aXN0aW5nRmlsZSkgPT4ge1xuXHRcdFx0XHRcdGlmIChleGlzdGluZ0ZpbGUubmFtZSA9PT0gZmlsZS5uYW1lKSB7XG5cdFx0XHRcdFx0XHRyZXR1cm4gZmlsZTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0cmV0dXJuIGV4aXN0aW5nRmlsZTtcblx0XHRcdFx0fSk7XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRuZXdDb25maWdGaWxlcyA9IFsuLi5jdXJyZW50RmlsZXMsIGZpbGVdO1xuXHRcdFx0fVxuXG5cdFx0XHRjb25zdCBzdG9yYWdlT2JqZWN0OiBJQ2hyb21lU3RvcmFnZSA9IHtcblx0XHRcdFx0Y29uZmlndXJhdGlvbnM6IG5ld0NvbmZpZ0ZpbGVzLFxuXHRcdFx0fTtcblx0XHRcdGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldChzdG9yYWdlT2JqZWN0LCAoKSA9PiB7XG5cdFx0XHRcdHJlc29sdmUobmV3Q29uZmlnRmlsZXMpO1xuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH1cblxuXHRwdWJsaWMgcmVtb3ZlQ29uZmlnRmlsZShmaWxlVG9SZW1vdmU6IElDb25maWdGaWxlKTogUHJvbWlzZTxJQ29uZmlnRmlsZVtdPiB7XG5cdFx0cmV0dXJuIG5ldyBQcm9taXNlKGFzeW5jIChyZXNvbHZlKSA9PiB7XG5cdFx0XHRjb25zdCBjdXJyZW50RmlsZXMgPSBhd2FpdCB0aGlzLmdldEFsbENvbmZpZ0ZpbGVzKCk7XG5cdFx0XHRjb25zdCBmaWx0ZXJlZENvbmZpZ0ZpbGVzID0gY3VycmVudEZpbGVzPy5maWx0ZXIoKGZpbGUpID0+IGZpbGUubmFtZSAhPT0gZmlsZVRvUmVtb3ZlLm5hbWUpO1xuXHRcdFx0Y29uc3Qgc3RvcmFnZU9iamVjdDogSUNocm9tZVN0b3JhZ2UgPSB7XG5cdFx0XHRcdGNvbmZpZ3VyYXRpb25zOiBmaWx0ZXJlZENvbmZpZ0ZpbGVzLFxuXHRcdFx0fTtcblx0XHRcdGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldChzdG9yYWdlT2JqZWN0LCAoKSA9PiB7XG5cdFx0XHRcdHJlc29sdmUoZmlsdGVyZWRDb25maWdGaWxlcyk7XG5cdFx0XHR9KTtcblx0XHR9KTtcblx0fVxuXG5cdHB1YmxpYyBnZXRBbGxDb25maWdGaWxlcygpOiBQcm9taXNlPElDb25maWdGaWxlW10+IHtcblx0XHRyZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcblx0XHRcdGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChbJ2NvbmZpZ3VyYXRpb25zJ10sICh7IGNvbmZpZ3VyYXRpb25zIH0pID0+IHtcblx0XHRcdFx0cmVzb2x2ZShjb25maWd1cmF0aW9ucz8ubGVuZ3RoID8gY29uZmlndXJhdGlvbnMgOiBbXSk7XG5cdFx0XHR9KTtcblx0XHR9KTtcblx0fVxuXG5cdGZpbHRlckNvbmZpZ3VyYXRpb25zRnJvbU9iamVjdChmaWx0ZXI6IFJlY29yZDxhbnksIHN0cmluZz4pOiBQcm9taXNlPElDb25maWdGaWxlW10gfCB1bmRlZmluZWQ+IHtcblx0XHRyZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcblx0XHRcdGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChbJ2NvbmZpZ3VyYXRpb25zJ10sICh7IGNvbmZpZ3VyYXRpb25zIH0pID0+IHtcblx0XHRcdFx0Y29uc3QgZmlsdGVyZWRDb25maWd1cmF0aW9ucyA9IGNvbmZpZ3VyYXRpb25zPy5maWx0ZXIoKGNvbmZpZzogSUNvbmZpZ0ZpbGUpID0+IHtcblx0XHRcdFx0XHRyZXR1cm4gT2JqZWN0LmVudHJpZXMoZmlsdGVyKS5zb21lKChbbWFwVmFsdWUsIGNvbmZpZ1JlcXVlc3RlZF0pID0+IHtcblx0XHRcdFx0XHRcdGNvbmZpZy5tYXBWYWx1ZSA9IG1hcFZhbHVlLnJlcGxhY2UoJ2NvbmZpZ05hbWUnLCAnZ2V0Q29uZmlndXJhdGlvbicpO1xuXHRcdFx0XHRcdFx0cmV0dXJuIGNvbmZpZ1JlcXVlc3RlZCA9PT0gY29uZmlnLm5hbWU7XG5cdFx0XHRcdFx0fSk7XG5cdFx0XHRcdH0pO1xuXHRcdFx0XHRyZXNvbHZlKGZpbHRlcmVkQ29uZmlndXJhdGlvbnM/Lmxlbmd0aCA/IGZpbHRlcmVkQ29uZmlndXJhdGlvbnMgOiB1bmRlZmluZWQpO1xuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH1cbn1cbiIsImltcG9ydCB7IERlYnVnZ2VyRmV0Y2gsIEV2ZW50UGFyYW1zIH0gZnJvbSAnQG1vZGVscy9jaHJvbWUtZGVidWdnZXIuaW50ZXJmYWNlJztcblxuLyoqXG4gKiBodHRwczovL2RldmVsb3Blci5jaHJvbWUuY29tL2RvY3MvZXh0ZW5zaW9ucy9yZWZlcmVuY2UvZGVidWdnZXIvXG4gKi9cbmV4cG9ydCBjbGFzcyBEZWJ1Z2dlclNlcnZpY2Uge1xuXHRwcml2YXRlIHN0YXRpYyBpbnN0YW5jZTogRGVidWdnZXJTZXJ2aWNlO1xuXG5cdHN0YXRpYyBnZXRJbnN0YW5jZSgpIHtcblx0XHRpZiAoIXRoaXMuaW5zdGFuY2UpIHtcblx0XHRcdHRoaXMuaW5zdGFuY2UgPSBuZXcgRGVidWdnZXJTZXJ2aWNlKCk7XG5cdFx0fVxuXHRcdHJldHVybiB0aGlzLmluc3RhbmNlO1xuXHR9XG5cblx0YXR0YWNoRGVidWdnZXJJbnN0YW5jZShkZWJ1Z2dlckluc3RhbmNlOiBjaHJvbWUuZGVidWdnZXIuRGVidWdnZWUpOiBQcm9taXNlPHVuZGVmaW5lZD4ge1xuXHRcdHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuXHRcdFx0Y2hyb21lLmRlYnVnZ2VyLmF0dGFjaChkZWJ1Z2dlckluc3RhbmNlLCAnMS4zJywgKCkgPT4gcmVzb2x2ZSgpKTtcblx0XHR9KTtcblx0fVxuXG5cdGRldGFjaERlYnVnZ2VySW5zdGFuY2UoZGVidWdnZXJJbnN0YW5jZTogY2hyb21lLmRlYnVnZ2VyLkRlYnVnZ2VlKTogUHJvbWlzZTx1bmRlZmluZWQ+IHtcblx0XHRyZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcblx0XHRcdGNocm9tZS5kZWJ1Z2dlci5kZXRhY2goZGVidWdnZXJJbnN0YW5jZSwgKCkgPT4gcmVzb2x2ZSgpKTtcblx0XHR9KTtcblx0fVxuXG5cdC8qKlxuXHQgKlxuXHQgKiBAcGFyYW0gZGVidWdnZXJJbnN0YW5jZVxuXHQgKiBAcGFyYW0gbWV0aG9kIGh0dHBzOi8vY2hyb21lZGV2dG9vbHMuZ2l0aHViLmlvL2RldnRvb2xzLXByb3RvY29sL1xuXHQgKiBAcGFyYW0gY29tbWFuZFBhcmFtc1xuXHQgKi9cblx0cHJpdmF0ZSBzZW5kQ29tbWFuZChcblx0XHRkZWJ1Z2dlckluc3RhbmNlOiBjaHJvbWUuZGVidWdnZXIuRGVidWdnZWUsXG5cdFx0bWV0aG9kOiBEZWJ1Z2dlckZldGNoLFxuXHRcdGNvbW1hbmRQYXJhbXM/OiBvYmplY3Rcblx0KTogUHJvbWlzZTxvYmplY3Q+IHtcblx0XHRyZXR1cm4gY2hyb21lLmRlYnVnZ2VyLnNlbmRDb21tYW5kKGRlYnVnZ2VySW5zdGFuY2UsIG1ldGhvZCwgY29tbWFuZFBhcmFtcyk7XG5cdH1cblxuXHRlbmFibGVGZXRjaChkZWJ1Z2dlckluc3RhbmNlOiBjaHJvbWUuZGVidWdnZXIuRGVidWdnZWUsIGNvbW1hbmRQYXJhbXM/OiBvYmplY3QpOiBQcm9taXNlPG9iamVjdD4ge1xuXHRcdHJldHVybiB0aGlzLnNlbmRDb21tYW5kKGRlYnVnZ2VySW5zdGFuY2UsIERlYnVnZ2VyRmV0Y2guZW5hYmxlLCBjb21tYW5kUGFyYW1zKTtcblx0fVxuXG5cdGNvbnRpbnVlUmVzcG9uc2UoZGVidWdnZXJJbnN0YW5jZTogY2hyb21lLmRlYnVnZ2VyLkRlYnVnZ2VlLCBjb21tYW5kUGFyYW1zOiBvYmplY3QpOiBQcm9taXNlPG9iamVjdCB8IHVuZGVmaW5lZD4ge1xuXHRcdHJldHVybiBjaHJvbWUuZGVidWdnZXIuc2VuZENvbW1hbmQoZGVidWdnZXJJbnN0YW5jZSwgRGVidWdnZXJGZXRjaC5jb250aW51ZVJlc3BvbnNlLCBjb21tYW5kUGFyYW1zKTtcblx0fVxuXG5cdGZ1bGZpbGxSZXF1ZXN0KGRlYnVnZ2VySW5zdGFuY2U6IGNocm9tZS5kZWJ1Z2dlci5EZWJ1Z2dlZSwgY29tbWFuZFBhcmFtczogb2JqZWN0KTogUHJvbWlzZTxvYmplY3QgfCB1bmRlZmluZWQ+IHtcblx0XHRyZXR1cm4gY2hyb21lLmRlYnVnZ2VyLnNlbmRDb21tYW5kKGRlYnVnZ2VySW5zdGFuY2UsIERlYnVnZ2VyRmV0Y2guZnVsZmlsbFJlcXVlc3QsIGNvbW1hbmRQYXJhbXMpO1xuXHR9XG5cblx0b25FdmVudChjYWxsYmFjazogKHNvdXJjZTogY2hyb21lLmRlYnVnZ2VyLkRlYnVnZ2VlLCBtZXRob2Q6IHN0cmluZywgcGFyYW1zPzogRXZlbnRQYXJhbXMpID0+IHZvaWQpIHtcblx0XHQvLyBAdHMtaWdub3JlXG5cdFx0Y2hyb21lLmRlYnVnZ2VyLm9uRXZlbnQuYWRkTGlzdGVuZXIoY2FsbGJhY2spO1xuXHR9XG59XG4iLCJpbXBvcnQgRXh0ZW5zaW9uUGFuZWwgPSBjaHJvbWUuZGV2dG9vbHMucGFuZWxzLkV4dGVuc2lvblBhbmVsO1xuXG5leHBvcnQgY2xhc3MgRGV2dG9vbHNTZXJ2aWNlIHtcblx0cHJpdmF0ZSBzdGF0aWMgaW5zdGFuY2U6IERldnRvb2xzU2VydmljZTtcblxuXHRzdGF0aWMgZ2V0SW5zdGFuY2UoKSB7XG5cdFx0aWYgKCF0aGlzLmluc3RhbmNlKSB7XG5cdFx0XHR0aGlzLmluc3RhbmNlID0gbmV3IERldnRvb2xzU2VydmljZSgpO1xuXHRcdH1cblx0XHRyZXR1cm4gdGhpcy5pbnN0YW5jZTtcblx0fVxuXG5cdGNyZWF0ZVBhbmVsKHRhYk5hbWU6IHN0cmluZywgcGF0aFRvSHRtbDogc3RyaW5nKTogUHJvbWlzZTxFeHRlbnNpb25QYW5lbD4ge1xuXHRcdHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuXHRcdFx0Y2hyb21lLmRldnRvb2xzLnBhbmVscy5jcmVhdGUodGFiTmFtZSwgJy4vYXNzZXRzL2ltYWdlcy9pY29uLTUwLnBuZycsIHBhdGhUb0h0bWwsIChwYW5lbCkgPT4ge1xuXHRcdFx0XHRyZXNvbHZlKHBhbmVsKTtcblx0XHRcdH0pO1xuXHRcdH0pO1xuXHR9XG59XG4iLCIvLyBUaGUgbW9kdWxlIGNhY2hlXG52YXIgX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fID0ge307XG5cbi8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG5mdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuXHR2YXIgY2FjaGVkTW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXTtcblx0aWYgKGNhY2hlZE1vZHVsZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0cmV0dXJuIGNhY2hlZE1vZHVsZS5leHBvcnRzO1xuXHR9XG5cdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG5cdHZhciBtb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdID0ge1xuXHRcdC8vIG5vIG1vZHVsZS5pZCBuZWVkZWRcblx0XHQvLyBubyBtb2R1bGUubG9hZGVkIG5lZWRlZFxuXHRcdGV4cG9ydHM6IHt9XG5cdH07XG5cblx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG5cdF9fd2VicGFja19tb2R1bGVzX19bbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG5cdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG5cdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbn1cblxuIiwiLy8gc3RhcnR1cFxuLy8gTG9hZCBlbnRyeSBtb2R1bGUgYW5kIHJldHVybiBleHBvcnRzXG4vLyBUaGlzIGVudHJ5IG1vZHVsZSBpcyByZWZlcmVuY2VkIGJ5IG90aGVyIG1vZHVsZXMgc28gaXQgY2FuJ3QgYmUgaW5saW5lZFxudmFyIF9fd2VicGFja19leHBvcnRzX18gPSBfX3dlYnBhY2tfcmVxdWlyZV9fKFwiLi9zcmMvZXh0ZW5zaW9ucy9kZXZ0b29scy9kZXZ0b29scy50c1wiKTtcbiJdLCJzb3VyY2VSb290IjoiIn0=